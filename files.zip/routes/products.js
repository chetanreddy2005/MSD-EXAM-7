import express from 'express';

const router = express.Router();

// In-memory product store
let products = [
  { id: 1, name: 'Laptop', price: 999 },
  { id: 2, name: 'Phone', price: 499 }
];

// GET /products - return all products
router.get('/', (req, res) => {
  res.json(products);
});

// POST /products - add a new product
router.post('/', (req, res) => {
  const { name, price } = req.body;
  if (!name || price === undefined) {
    return res.status(400).json({ error: 'Name and price are required.' });
  }
  const newProduct = {
    id: products.length + 1,
    name,
    price
  };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

export default router;