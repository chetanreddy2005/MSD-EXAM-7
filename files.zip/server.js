import express from 'express';
import cors from 'cors';
import os from 'os';
import http from 'http';
import productsRouter from './routes/products.js';

const app = express();
const PORT = 4000;

// Use CORS and JSON parsing middleware
app.use(cors());
app.use(express.json());

// Log method and URL of every request using http module
app.use((req, res, next) => {
  // Log with http module
  http
    .request(
      {
        method: req.method,
        path: req.url,
        host: 'localhost'
      },
      () => {}
    )
    .end();
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// Use products routes
app.use('/products', productsRouter);

// Print system info using os module when server starts
console.log('--- System Information ---');
console.log(`Platform: ${os.platform()}`);
console.log(`CPU Cores: ${os.cpus().length}`);
console.log('--------------------------');

// Start server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});